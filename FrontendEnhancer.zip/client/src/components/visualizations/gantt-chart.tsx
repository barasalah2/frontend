import { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface GanttChartProps {
  data: any[];
}

export function GanttChart({ data }: GanttChartProps) {
  const chartData = useMemo(() => {
    if (!data || data.length === 0) return [];
    
    return data.map((item, index) => {
      // Extract progress from different possible field names
      let progress = 0;
      if (item.Progress) {
        progress = parseInt(String(item.Progress).replace('%', '')) || 0;
      } else if (item.progress) {
        progress = item.progress;
      }

      return {
        name: item['WP ID'] || item.id || item.name || `Item ${index + 1}`,
        progress: progress,
        status: item.Status || item.status || 'Unknown',
        description: item.Description || item.description || '',
        dueDate: item['Due Date'] || item.dueDate || '',
        team: item['Assigned Team'] || item.assignedTeam || ''
      };
    });
  }, [data]);

  const getStatusColor = (status: string, progress: number) => {
    if (progress >= 100) return '#10b981'; // green
    if (status.toLowerCase().includes('delayed')) return '#ef4444'; // red
    if (status.toLowerCase().includes('progress')) return '#3b82f6'; // blue
    if (status.toLowerCase().includes('planned')) return '#f59e0b'; // amber
    return '#6b7280'; // gray
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white dark:bg-slate-800 p-3 border border-gray-200 dark:border-slate-700 rounded-lg shadow-lg">
          <p className="font-semibold text-workpack-text dark:text-white">{label}</p>
          <p className="text-sm text-workpack-slate dark:text-slate-400">{data.description}</p>
          <p className="text-sm">
            <span className="font-medium">Progress:</span> {data.progress}%
          </p>
          <p className="text-sm">
            <span className="font-medium">Status:</span> {data.status}
          </p>
          {data.dueDate && (
            <p className="text-sm">
              <span className="font-medium">Due:</span> {data.dueDate}
            </p>
          )}
          {data.team && (
            <p className="text-sm">
              <span className="font-medium">Team:</span> {data.team}
            </p>
          )}
        </div>
      );
    }
    return null;
  };

  if (!chartData || chartData.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-workpack-slate dark:text-slate-400">
        No data available for visualization
      </div>
    );
  }

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={chartData}
          margin={{ top: 20, right: 30, left: 20, bottom: 60 }}
          layout="horizontal"
        >
          <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
          <XAxis 
            type="number" 
            domain={[0, 100]}
            tickFormatter={(value) => `${value}%`}
          />
          <YAxis 
            type="category" 
            dataKey="name" 
            width={120}
            tick={{ fontSize: 12 }}
          />
          <Tooltip content={<CustomTooltip />} />
          <Bar dataKey="progress" radius={[0, 4, 4, 0]}>
            {chartData.map((entry, index) => (
              <Cell 
                key={`cell-${index}`} 
                fill={getStatusColor(entry.status, entry.progress)}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}